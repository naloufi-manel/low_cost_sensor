
bool readSerial(char result[]);
