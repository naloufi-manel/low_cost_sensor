void readDO(float voltage_mv, int temperature_c, float *od1,float *od2);
void calibr_DO(char cmd[10], float volt, float temperature);
