
double turbidity(float volt);

void calibr_k(char cmd[10],float volt);
